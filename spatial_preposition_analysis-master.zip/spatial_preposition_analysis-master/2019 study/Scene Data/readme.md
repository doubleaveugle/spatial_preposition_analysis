To keep the analysis folder self contained, the relations.csv file from the feature extraction process is manually copied here.
See `Scene Data` folder from `Unity3D Annotation Environment`.